package persistentie;

import domein.Bier;
import java.util.List;

public class BierMapper {

    public List<Bier> inlezenBieren(String naamBestand) {
//TODO
        return null;
    }

}
